//
//  Icon.swift
//  AtAGlanceCollectionView
//
//  Created by Romain on 26/12/2016.
//  Copyright © 2016 Romain. All rights reserved.
//

import UIKit

class Icon: NSObject, NSCoding {
    
    // MARK: Properties
    
    
    var icon: UIImage?
    
    
    // MARK: Archiving Paths
    
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("icons")
    
    // MARK: Types
    
    struct PropertyKey {
        
        
        static let iconKey = "icon"
        
        
    }
    
    // MARK: Initialization
    
    init?(icon: UIImage?) {
        
        // Initialize stored properties.
        
        
        self.icon = icon
        
        
        super.init()
        
    }
    
    func encode(with aCoder: NSCoder) {
        
        
        aCoder.encode(icon, forKey: PropertyKey.iconKey)
        
        
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        
        
        let icon = aDecoder.decodeObject(forKey: PropertyKey.iconKey) as? UIImage
        
        
        // Must call designated initializer
        
        self.init(icon: icon)
        
    }
    
}







