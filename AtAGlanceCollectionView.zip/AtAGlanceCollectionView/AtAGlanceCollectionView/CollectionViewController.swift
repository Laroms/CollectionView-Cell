//
//  ViewController.swift
//  AtAGlanceCollectionView
//
//  Created by Romain on 25/12/2016.
//  Copyright © 2016 Romain. All rights reserved.
//

import UIKit

class CollectionViewController: UICollectionViewController {

    var iconImg = [Icon]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return iconImg.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cellIdentifier = "glanceCell"
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as! GlanceCell

        return cell
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "ShowIconDetail" {
            let lessonIconTableViewController = segue.destination as! LessonIconTableViewController
            
            // Get the cell that generated this segue
            
            if let selectedGlanceCell = sender as? GlanceCell {
                let indexPath = collectionView?.indexPath(for: selectedGlanceCell)!
                let selectedIconImg = iconImg[((indexPath)?.item)!]
                lessonIconTableViewController.iconImage = selectedIconImg
                
            }
            
        }
            
        else if segue.identifier == "AddIcon" {
            print("Adding new icon")
            
        }
        
    }
    
    @IBAction func saveToCollectionViewController(_ sender: UIStoryboardSegue) {
        
        if let sourceViewController = sender.source as? LessonIconTableViewController, let iconImage = sourceViewController.iconImage {
                
                // Add a new icon image.
                let newIndexPath = IndexPath(item: iconImg.count, section: 0)
                iconImg.append(iconImage)
                collectionView?.insertItems(at: [newIndexPath])
                
            }
        }
    
    @IBAction func cancelToCollectionViewController(_ segue:UIStoryboardSegue) {
        
    }
}
