//
//  GlanceCell.swift
//  AtAGlanceCollectionView
//
//  Created by Romain on 25/12/2016.
//  Copyright © 2016 Romain. All rights reserved.
//

import UIKit

class GlanceCell: UICollectionViewCell {
    
    @IBOutlet weak var lessonImg: UIImageView!
    
    
}
