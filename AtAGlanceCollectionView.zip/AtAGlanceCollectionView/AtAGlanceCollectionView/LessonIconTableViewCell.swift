//
//  LessonIconTableViewCell.swift
//  AtAGlanceCollectionView
//
//  Created by Romain on 25/12/2016.
//  Copyright © 2016 Romain. All rights reserved.
//

import UIKit

class LessonIconTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
