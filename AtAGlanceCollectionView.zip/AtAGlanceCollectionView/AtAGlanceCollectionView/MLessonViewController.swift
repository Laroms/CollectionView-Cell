//
//  MLessonViewController.swift
//  SchoolTime
//
//  Created by Romain DECOTTE on 08/03/2016.
//  Copyright © 2016 Romain DECOTTE. All rights reserved.
//

import UIKit

class MLessonViewController: UITableViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var timeTextField: UITextField!
    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var lessonNumberImage: UIImageView!
    @IBOutlet weak var placeTextField: UITextField!
    @IBOutlet weak var hwdImage: UIImageView!
    @IBOutlet weak var subjectImage: UIImageView!
    @IBOutlet weak var nextLImage: UIImageView!
    
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    var lNumImage: UIImage = UIImage (named: "French")! {
        didSet {
            lessonNumberImage.image = lNumImage
        }
    }
    
    var subjImage: UIImage = UIImage(named: "French")! {
        didSet {
            subjectImage.image = subjImage
        }
    }
    
    var hWDImage: UIImage = UIImage(named: "French")! {
        didSet {
            hwdImage.image = hWDImage
        }
    }
    
    var nXTLessonImage: UIImage = UIImage(named: "French")! {
        didSet {
            nextLImage.image = nXTLessonImage
        }
    }
    
    /*
    This value is either passed by `MWALessonsViewController` in `prepareForSegue(_:sender:)`
    or constructed as part of adding a new lesson.
    */
    
    var lesson: Lesson?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let titleButton: UIButton = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 32))
        titleButton.setTitle(NSLocalizedString("ADD_/_EDIT_LESSON", comment: "Add/Edit Lesson"), for: UIControlState())
        titleButton.titleLabel?.font = UIFont(name: "CollegiateHeavyOutline", size: 17.0)
        titleButton.titleLabel?.numberOfLines = 2
        titleButton.titleLabel?.textAlignment = .center
        titleButton.setTitleColor(UIColor.init(red: 56.0/255.0, green: 205.0/255.0, blue: 231.0/255.0, alpha: 1.0), for: UIControlState())
        self.navigationItem.titleView = titleButton
        
        self.timeTextField.delegate = self
        self.yearTextField.delegate = self
        self.placeTextField.delegate = self
        
        if self.revealViewController() != nil {
            
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        // Set up views if editing an existing Lesson.
        
        if let lesson = lesson {
            
            timeTextField.text = lesson.time
            yearTextField.text = lesson.year
            placeTextField.text = lesson.place
            lessonNumberImage.image = lesson.lessonNumImage
            subjectImage.image = lesson.sImage
            hwdImage.image = lesson.homeworkDayImage
            nextLImage.image = lesson.nextLessonImage
            
        }
        
        timeTextField.placeholder = NSLocalizedString("TYPE_IN_START_TIME", comment: "start time")
        timeTextField.font = UIFont(name: "Wallpoet", size: 19.0)
        timeTextField.adjustsFontSizeToFitWidth = true
        timeTextField.textAlignment = .center
        
        yearTextField.placeholder = NSLocalizedString("TYPE_IN_YEAR_GROUP", comment: "Year group")
        yearTextField.font = UIFont(name: "PermanentMarker", size: 19.0)
        yearTextField.adjustsFontSizeToFitWidth = true
        yearTextField.textAlignment = .center
        
        placeTextField.placeholder = NSLocalizedString("TYPE_IN_CLASSROOM_NUMBER_OR_PLACE", comment: "Place")
        placeTextField.font = UIFont(name: "PermanentMarker", size: 19.0)
        placeTextField.adjustsFontSizeToFitWidth = true
        placeTextField.textAlignment = .center
        
        
    }
    
        // Dismiss keyboard when return key is tapped.
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        timeTextField.resignFirstResponder()
        yearTextField.resignFirstResponder()
        placeTextField.resignFirstResponder()
        
        
        return true;
    }
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        let header = view as! UITableViewHeaderFooterView
        header.textLabel!.textColor = UIColor(red: 56.0/255.0, green: 205.0/255.0, blue: 231.0/255.0, alpha: 0.7)
        header.textLabel!.font = UIFont(name: "collegiateHeavyOutline", size: 20)
        header.textLabel!.frame = header.frame
        header.textLabel!.textAlignment = NSTextAlignment.center
    }
    
        // Tap anywhere in the row to bring up keyboard.
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (indexPath as NSIndexPath).section == 0 {
            
            timeTextField.becomeFirstResponder()
            yearTextField.resignFirstResponder()
            placeTextField.resignFirstResponder()
            
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Navigation
    
    // This method lets you configure a view controller before it's presented.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SaveLessonDetail" {
            lesson = Lesson(time: timeTextField.text!, year: yearTextField.text!, place: placeTextField.text!, lessonNumImage: lessonNumberImage.image, sImage: subjectImage.image, homeworkDayImage: hwdImage.image, nextLessonImage: nextLImage.image)
            
            if segue.identifier == "PickLessonNumberImage" {
                if let lessonNumberImagePickerViewController = segue.destination as? LessonNumberImagePickerViewController {
                    lessonNumberImagePickerViewController.selectedLessonNumberImage = lNumImage
                
                if segue.identifier == "PickSubjectImage" {
                    if let subjectImagePickerViewController = segue.destination as? subjectImagePickerViewController {
                            subjectImagePickerViewController.selectedSubjectImage = subjImage
                        
                        if segue.identifier == "PickHomeworkDayImage" {
                            if let homeworkDayImagePickerViewController = segue.destination as? HomeworkDayImagePickerViewController {
                                homeworkDayImagePickerViewController.selectedHomeworkDayImage = hWDImage
                                
                                if segue.identifier == "PickNextLessonImage" {
                                    if let nextLessonImagePickerViewController = segue.destination as? NextLessonImagePickerViewController {
                                        nextLessonImagePickerViewController.selectedNextLessonImage = nXTLessonImage
                                
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
        
        if let sender = sender as? UIBarButtonItem, sender === saveButton {
    
            let time = timeTextField.text ?? ""
            let year = yearTextField.text ?? ""
            let lessonNumImage = lessonNumberImage.image
            let sImage = subjectImage.image
            let place = placeTextField.text ?? ""
            let homeworkDayImage = hwdImage.image
            let nextLessonImage = nextLImage.image
            
            // Set the meal to be passed to MWALessonsViewController after the unwind segue.
            lesson = Lesson(time: time, year: year, place: place, lessonNumImage: lessonNumImage, sImage: sImage, homeworkDayImage: homeworkDayImage, nextLessonImage: nextLessonImage)
            
            }
        }
    
    
    // Unwind with selected subject image
    
    @IBAction func unwindWithSelectedSubjectImage(_ segue:UIStoryboardSegue) {
    if let subjectImagePickerViewController = segue.source as? subjectImagePickerViewController,
    let selectedSubjectImage = subjectImagePickerViewController.selectedSubjectImage {
        subjImage = selectedSubjectImage
        
            }
        }
    
    // Unwind with selected lesson number image
    
    @IBAction func unwindWithSelectedLessonNumberImage(_ segue:UIStoryboardSegue) {
        if let lessonNumberImagePickerViewController = segue.source as? LessonNumberImagePickerViewController,
            let selectedLessonNumberImage = lessonNumberImagePickerViewController.selectedLessonNumberImage {
            lNumImage = selectedLessonNumberImage
            
        }
    }
    
    // Unwind with selected homework day image
    
    @IBAction func unwindWithSelectedHomeworkDayImage(_ segue:UIStoryboardSegue) {
        if let homeworkDayImagePickerViewController = segue.source as? HomeworkDayImagePickerViewController,
            let selectedHomeworkDayImage = homeworkDayImagePickerViewController.selectedHomeworkDayImage {
            hWDImage = selectedHomeworkDayImage
            
        }
    }
    
    // Unwind with selected next lesson image
    
    @IBAction func unwindWithSelectedNextLessonImage(_ segue:UIStoryboardSegue) {
        if let nextLessonImagePickerViewController = segue.source as? NextLessonImagePickerViewController,
            let selectedNextLessonImage = nextLessonImagePickerViewController.selectedNextLessonImage {
            nXTLessonImage = selectedNextLessonImage
            
        }
    }
    
}
