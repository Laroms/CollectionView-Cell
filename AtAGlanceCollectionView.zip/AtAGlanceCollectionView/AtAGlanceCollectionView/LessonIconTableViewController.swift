//
//  LessonIconTableViewController.swift
//  AtAGlanceCollectionView
//
//  Created by Romain on 25/12/2016.
//  Copyright © 2016 Romain. All rights reserved.
//

import UIKit

class LessonIconTableViewController: UITableViewController {

    @IBOutlet weak var lessonIcon: UIImageView!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    
    var lIconImage: UIImage = UIImage (named: "Lesson1")! {
        didSet {
            lessonIcon.image = lIconImage
        }
    }
    
    var iconImage: Icon?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up views if editing an existing Lesson.
        
        if let icon = iconImage {
            
            
            lessonIcon.image = icon.icon
            
            
        }

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Navigation
    
    // This method lets you configure a view controller before it's presented.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SaveLessonIconImage" {
            
            iconImage = Icon(icon:lessonIcon.image)
            
        }
    
    
            if segue.identifier == "PickLessonIconImage" {
                if let iconPickerTableViewController = segue.destination as? IconPickerTableViewController {
                    iconPickerTableViewController.selectedLessonIconImage = lIconImage
            }
    
        }
        
        if let sender = sender as? UIBarButtonItem, sender === saveButton {
            
            let icon = lessonIcon.image
            
            // Set the meal to be passed to MWALessonsViewController after the unwind segue.
            iconImage = Icon(icon: icon)
            
        }
        
    }
    
                

    // Unwind with selected lesson number image
    
    @IBAction func unwindWithSelectedLessonIconImage(_ segue:UIStoryboardSegue) {
        if let iconPickerTableViewController = segue.source as? IconPickerTableViewController,
            let selectedLessonIconImage = iconPickerTableViewController.selectedLessonIconImage {
            lIconImage = selectedLessonIconImage
            
        
        
        
        }
    }
}
